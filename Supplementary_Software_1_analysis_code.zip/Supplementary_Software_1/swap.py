"""Spatial swap analysis (Methods 2.10): loss zones, swap coverage, candidate contribution, swap depth."""
import pickle
import sys
import time

import numpy as np

sys.path.insert(0, ".")
from common import ALL, FUT, H, ROWAREA, W, read_africa

mask = np.load("./afmask.npy")
# Groundnut and sweetpotato are omitted: their rasters are byte-identical to the taro file.
GROUPS = {
    "Cereals": (["maize", "wheat", "rice", "pearl_millet"], ["fonio", "teff", "sorghum"]),
    "Legumes": (["common_bean", "chickpea"], ["bambara_nut", "african_yam_bean", "kerstrings_groundnut", "cowpea", "marama_beans"]),
    "Roots and tubers": (["cassava", "banana_plantain"], ["taro", "tiger_nut", "african_yam"]),
}
crops = sorted({c for g in GROUPS.values() for l in g for c in l})
DS = 10
res = {}
maps = {c: np.full(((H + DS - 1) // DS, (W + DS - 1) // DS), 255, np.uint8) for g in GROUPS.values() for c in g[0]}


def acc(key, name, val):
    d = res.setdefault(key, {})
    d[name] = d.get(name, 0.0) + val


t0 = time.time()
STRIP = 400
for r0 in range(0, H, STRIP):
    n = min(STRIP, H - r0)
    m = mask[r0:r0 + n]
    A = np.broadcast_to(ROWAREA[r0:r0 + n, None], (n, W))
    data = {c: {s: read_africa(c, s, r0, n) for s in ALL} for c in crops}
    for gname, (commons, cands) in GROUPS.items():
        settings = {
            "main": (cands, 2, False),
            "high only": (cands, 3, False),
            "stable": (cands, 2, True),
            "excl. contested": ([u for u in cands if u not in ("sorghum", "cowpea")], 2, False),
        }
        if gname == "Roots and tubers":
            settings["excl. taro"] = ([u for u in cands if u != "taro"], 2, False)
            settings["tiger nut only"] = (["tiger_nut"], 2, False)
        for com in commons:
            cur = data[com]["current"]
            fav0 = (cur >= 2) & (cur != 255) & m
            lossS = {s: fav0 & (data[com][s] <= 1) for s in FUT}
            robloss = lossS[FUT[0]] & lossS[FUT[1]] & lossS[FUT[2]]
            for sname, (cl, thr, stable) in settings.items():
                def viable(u, s):
                    f = data[u][s]
                    v = (f >= thr) & (f != 255)
                    if stable:
                        c0 = data[u]["current"]
                        v &= (c0 >= thr) & (c0 != 255)
                    return v
                acc((com, sname, "current"), "fav0", float(A[fav0].sum()))
                for s in FUT:
                    L = lossS[s]
                    V = {u: viable(u, s) for u in cl}
                    nv = sum(V[u].astype(np.uint8) for u in cl)
                    key = (com, sname, s)
                    acc(key, "loss", float(A[L].sum()))
                    acc(key, "covered", float(A[L & (nv > 0)].sum()))
                    acc(key, "depthsum", float((A * nv)[L].sum()))
                    for u in cl:
                        acc(key, "cc_" + u, float(A[L & V[u]].sum()))
                Vr = {u: viable(u, FUT[0]) & viable(u, FUT[1]) & viable(u, FUT[2]) for u in cl}
                nr = sum(Vr[u].astype(np.uint8) for u in cl)
                key = (com, sname, "robust")
                acc(key, "loss", float(A[robloss].sum()))
                acc(key, "covered", float(A[robloss & (nr > 0)].sum()))
                acc(key, "depthsum", float((A * nr)[robloss].sum()))
                for u in cl:
                    acc(key, "cc_" + u, float(A[robloss & Vr[u]].sum()))
                if sname == "main":
                    code = np.full((n, W), 255, np.uint8)
                    code[m] = 0
                    code[robloss] = 1
                    code[robloss & (nr == 1)] = 2
                    code[robloss & (nr >= 2)] = 3
                    off = (-r0) % DS
                    sub = code[off::DS, ::DS]
                    maps[com][(r0 + off) // DS:(r0 + off) // DS + sub.shape[0], :sub.shape[1]] = sub
    print(r0, round(time.time() - t0), flush=True)
pickle.dump({"res": res, "maps": maps, "groups": GROUPS}, open("./swap.pkl", "wb"))
print("done")
