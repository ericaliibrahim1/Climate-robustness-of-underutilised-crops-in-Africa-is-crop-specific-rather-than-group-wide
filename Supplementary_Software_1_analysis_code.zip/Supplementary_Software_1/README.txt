Supplementary Software 1 - analysis code
=========================================
Python 3.13 with numpy 2.5, pandas 3.0, scipy 1.18, rasterio 1.5, shapely 2.2,
matplotlib 3.11 and adjustText.

Place in this folder:
  rasters/                                    classified suitability rasters
                                              (<scenario>_continuous_<crop>_classified.tif;
                                              scenario = current, best (SSP1-2.6),
                                              moderate (SSP2-4.5), worst (SSP5-8.5);
                                              classes 0-3, 255 = no data)
  ne50.geojson                                Natural Earth 1:50m admin-0 countries
  Supplementary_Data_1_suitability_areas.xlsx Supplementary Data 1

Run in this order:
  1. python areas.py   class areas (Africa and global) and class transitions -> areas.pkl
  2. python swap.py    loss zones, swap coverage, candidate contribution, depth -> swap.pkl
  3. python stats.py   group comparison, sensitivity, ranking tests, quadrants -> stats.pkl,
                       crop_metrics_37.csv
  4. python figs.py    Figures 1-5 -> figs/

Shared settings (file names, scenarios, Africa mask, cell areas) are in common.py.
Random seeds: permutation test seed = 1 (20,000 permutations); figure jitter seed = 7.
