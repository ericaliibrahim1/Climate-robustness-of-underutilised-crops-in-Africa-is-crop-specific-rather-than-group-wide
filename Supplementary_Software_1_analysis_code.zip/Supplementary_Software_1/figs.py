"""Nature-style figures for the Results section."""
import json
import pickle
import sys

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from adjustText import adjust_text
from matplotlib.colors import BoundaryNorm, ListedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

sys.path.insert(0, ".")
from common import H, W, WTR

OUT = "./figs/"
S = pickle.load(open("./stats.pkl", "rb"))
SW = pickle.load(open("./swap.pkl", "rb"))
df = pd.DataFrame(S["df"])

INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"
COL = {"U": "#eb6834", "C": "#2a78d6"}
SCN = {"SSP1-2.6": "#b9b8b1", "SSP2-4.5": "#7d7c76", "SSP5-8.5": "#3b3a37"}
BAR = {"SSP1-2.6": "#86b6ef", "SSP2-4.5": "#2a78d6", "SSP5-8.5": "#104281"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 7, "axes.edgecolor": INK2, "axes.linewidth": 0.6,
                     "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "xtick.major.width": 0.6,
                     "ytick.major.width": 0.6, "legend.frameon": False, "savefig.dpi": 400})
MM = 1 / 25.4


def clean(ax, grid="x"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    if grid:
        ax.grid(axis=grid, color=GRID, lw=0.5, zorder=0)
    ax.set_axisbelow(True)


def panel(ax, letter, x=-0.02, y=1.02):
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=9, fontweight="bold", va="bottom", ha="right")


# ---------------- Fig. 1 ranking with scenario spread
d = df.sort_values("Dbar")
fig, ax = plt.subplots(figsize=(120 * MM, 150 * MM))
y = np.arange(len(d))
ax.axvline(0, color=INK2, lw=0.6, zorder=1)
for yi, (_, r) in zip(y, d.iterrows()):
    xs = [r.D1, r.D2, r.D5]
    ax.plot([min(xs), max(xs)], [yi, yi], color="#dcdbd5", lw=1.6, solid_capstyle="round", zorder=2)
    for s, v, mk in zip(["SSP1-2.6", "SSP2-4.5", "SSP5-8.5"], xs, ["o", "s", "^"]):
        ax.scatter(v, yi, s=9, marker=mk, color=SCN[s], zorder=3, lw=0)
    ax.scatter(r.Dbar, yi, s=26, marker="D", color=COL[r.group], edgecolor="white", lw=0.6, zorder=4)
ax.set_yticks(y)
ax.set_yticklabels(d.label, fontsize=6.5, color=INK)
ax.set_ylim(-0.8, len(d) - 0.2)
ax.set_xlabel("Change in moderate + high suitability area in Africa (%)")
clean(ax)
h = [Line2D([], [], marker="D", ls="", color=COL["U"], ms=4.5, label="Mean ($\\bar{\\Delta}$), underutilised"),
     Line2D([], [], marker="D", ls="", color=COL["C"], ms=4.5, label="Mean ($\\bar{\\Delta}$), commonly cultivated"),
     Line2D([], [], marker="o", ls="", color=SCN["SSP1-2.6"], ms=3.5, label="SSP1-2.6"),
     Line2D([], [], marker="s", ls="", color=SCN["SSP2-4.5"], ms=3.5, label="SSP2-4.5"),
     Line2D([], [], marker="^", ls="", color=SCN["SSP5-8.5"], ms=3.5, label="SSP5-8.5"),
     Line2D([], [], color="#dcdbd5", lw=1.6, label="Range across scenarios ($R_\\Delta$)")]
ax.legend(handles=h, loc="lower right", fontsize=6, handletextpad=0.3, labelspacing=0.35, frameon=True, facecolor="white", edgecolor="white", framealpha=1)
plt.tight_layout()
fig.savefig(OUT + "fig1_ranking.png")
plt.close(fig)

# ---------------- Fig. 2 within-category and high-suitability change
cats = ["Cereal", "Legume", "Root and tuber", "Leafy vegetable", "Fruit and tree", "Oilseed", "Agroforestry"]
fig, (a, b) = plt.subplots(1, 2, figsize=(183 * MM, 115 * MM), gridspec_kw={"width_ratios": [1.0, 1]})
yt, yl = [], []
yy = 0
import matplotlib.transforms as mtrans
tr = mtrans.blended_transform_factory(a.transAxes, a.transData)
for cat in cats:
    g = df[df.category == cat].sort_values("Dbar")
    a.text(-0.01, yy, {"Cereal": "Cereals", "Legume": "Legumes", "Root and tuber": "Roots and tubers", "Leafy vegetable": "Leafy vegetables",
                       "Fruit and tree": "Fruit and tree crops", "Oilseed": "Oilseeds", "Agroforestry": "Agroforestry trees"}[cat],
           transform=tr, ha="right", va="center", fontsize=6.5, fontweight="bold", color=INK)
    ys = yy + 1 + np.arange(len(g))
    for yi, (_, r) in zip(ys, g.iterrows()):
        a.plot([0, r.Dbar], [yi, yi], color=GRID, lw=0.8, zorder=1)
        a.scatter(r.Dbar, yi, s=18, color=COL[r.group], zorder=3, edgecolor="white", lw=0.5)
        yt.append(yi)
        yl.append(r.label)
    yy += len(g) + 1.6
a.set_yticks(yt)
a.set_yticklabels(yl, fontsize=5.8, color=INK)
a.axvline(0, color=INK2, lw=0.6)
a.set_xlim(-60, 10)
a.invert_yaxis()
a.set_xlabel("Mean change in moderate + high area, $\\bar{\\Delta}$ (%)")
clean(a)
a.tick_params(axis="y", length=0, pad=2)
panel(a, "a", x=-0.45)
lim = (-90, 15)
b.plot(lim, lim, color=INK2, lw=0.6, ls="--", zorder=1)
b.axhline(0, color=GRID, lw=0.6)
b.axvline(0, color=GRID, lw=0.6)
for g in ("U", "C"):
    s = df[df.group == g]
    b.scatter(s.Dbar, s.DHbar, s=16, color=COL[g], edgecolor="white", lw=0.5, zorder=3,
              label="Underutilised" if g == "U" else "Commonly cultivated")
lab = ["velvet", "sesame", "kola", "mango", "marama", "bean", "teff", "millet", "rice", "calliandra"]
texts = [b.text(r.Dbar, r.DHbar, r.label, fontsize=5.8, color=INK) for _, r in df[df.key.isin(lab)].iterrows()]
adjust_text(texts, ax=b, min_arrow_len=0, expand=(1.4, 1.8), arrowprops=dict(arrowstyle="-", color=INK2, lw=0.4))
b.set_xlim(*lim)
b.set_ylim(-95, 15)
b.set_xlabel("Mean change in moderate + high area, $\\bar{\\Delta}$ (%)")
b.set_ylabel("Mean change in high-suitability area, $\\bar{\\Delta}_H$ (%)")
b.legend(loc="upper left", fontsize=6)
b.text(-60, -66, "1:1", fontsize=6, color=INK2, rotation=40)
clean(b, grid=None)
panel(b, "b", x=-0.12)
plt.tight_layout()
fig.savefig(OUT + "fig2_category_high.png")
plt.close(fig)

# ---------------- Fig. 3 quadrant
rng = np.random.default_rng(7)
q = df.copy()
q["x"] = q.tier + rng.uniform(-0.28, 0.28, len(q))
med = S["median"]
fig, ax = plt.subplots(figsize=(183 * MM, 120 * MM))
ax.axvspan(-0.5, 1.5, color="#f6f1e9", zorder=0)
ax.axvspan(1.5, 3.5, color="#eef3f8", zorder=0)
ax.axhline(med, color=INK2, ls="--", lw=0.7)
ax.axvline(1.5, color=INK2, ls="--", lw=0.7)
size = lambda r: 12 + r ** 2 * 1.4
for g, labg in (("U", "Underutilised"), ("C", "Commonly cultivated")):
    s = q[q.group == g]
    ax.scatter(s.x, s.Dbar, s=size(s.R), color=COL[g], alpha=0.9, edgecolor="white", lw=0.6, label=labg, zorder=3)
texts = [ax.text(r.x, r.Dbar, r.label + ("*" if r.key in ("sorghum", "cowpea") else ""), fontsize=5.8, color=INK, zorder=5)
         for _, r in q.iterrows()]
adjust_text(texts, ax=ax, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.4))
ax.set_xlim(-0.5, 3.5)
ax.set_ylim(-62, 12)
ax.set_xticks([0, 1, 2, 3])
ax.set_xticklabels(["Tier 0\nNo CGIAR lead", "Tier 1\nNon-CGIAR institution or\ndocumentation only",
                    "Tier 2\nCGIAR genebank or\ndomestication programme", "Tier 3\nCGIAR mandate crop\nwith breeding programme"], fontsize=6.3)
ax.set_ylabel("Mean change in moderate + high suitability area, $\\bar{\\Delta}$ (%)")
kw = dict(fontsize=6.8, fontweight="bold", color=INK2)
ax.text(-0.45, 10.5, "Neglected opportunities", va="top", **kw)
ax.text(3.45, 10.5, "Well placed", va="top", ha="right", **kw)
ax.text(0.45, -60.5, "Low climate priority", va="bottom", **kw)
ax.text(3.45, -60.5, "Investment at risk", va="bottom", ha="right", **kw)
for r in (3, 8, 13):
    ax.scatter([], [], s=size(r), color="#a9a8a1", label=f"$R_\\Delta$ = {r} pp")
ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.24), ncol=5, fontsize=6)
clean(ax, grid=None)
plt.tight_layout()
fig.savefig(OUT + "fig3_quadrant.png")
plt.close(fig)

# ---------------- Fig. 4 swap maps
g = json.load(open("./ne50.geojson"))
af = [f for f in g["features"] if f["properties"].get("CONTINENT") == "Africa"]
ext = [WTR.c, WTR.c + W * WTR.a, WTR.f + H * WTR.e, WTR.f]
cmap = ListedColormap(["#ebeae6", "#eb6834", "#5598e7", "#184f95"])
NM = {"maize": "Maize", "wheat": "Wheat", "rice": "Asian rice", "pearl_millet": "Pearl millet", "common_bean": "Common bean",
      "chickpea": "Chickpea", "cassava": "Cassava", "banana_plantain": "Banana and plantain"}
order = list(NM)
sw = S["swap"]
fig, axs = plt.subplots(2, 4, figsize=(183 * MM, 112 * MM))
for i, (ax, c) in enumerate(zip(axs.flat, order)):
    m = np.ma.masked_equal(SW["maps"][c], 255)
    ax.imshow(m, cmap=cmap, norm=BoundaryNorm([-.5, .5, 1.5, 2.5, 3.5], 4), extent=ext, interpolation="nearest")
    for f in af:
        geom = f["geometry"]
        polys = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
        for p in polys:
            x, yv = np.array(p[0]).T
            ax.plot(x, yv, color="#9a9992", lw=0.2)
    r = sw[c]["main"]["robust"]
    ax.set_title(f"{NM[c]}\nloss {r['loss'] / 1e6:.2f} M km² · coverage {r['SC']:.0f}%", fontsize=6.5, color=INK)
    ax.set_xlim(-19, 53)
    ax.set_ylim(-36, 38)
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    ax.text(0.02, 0.98, "abcdefgh"[i], transform=ax.transAxes, fontsize=9, fontweight="bold", va="top")
fig.legend(handles=[Patch(color="#ebeae6", label="Not lost under all three SSPs"),
                    Patch(color="#eb6834", label="Robust loss, no candidate viable"),
                    Patch(color="#5598e7", label="Robust loss, one candidate viable"),
                    Patch(color="#184f95", label="Robust loss, two or more candidates viable")],
           loc="lower center", ncol=2, fontsize=6.3, bbox_to_anchor=(0.5, 0.0))
plt.subplots_adjust(left=0.01, right=0.99, top=0.93, bottom=0.11, hspace=0.25, wspace=0.03)
fig.savefig(OUT + "fig4_swap_maps.png")
plt.close(fig)

# ---------------- Fig. 5 coverage by scenario + candidate contribution heatmap
cands = ["fonio", "teff", "sorghum", "bambara_nut", "african_yam_bean", "kerstrings_groundnut", "cowpea", "marama_beans", "taro", "tiger_nut", "african_yam"]
CN = {"fonio": "White fonio", "teff": "Teff", "sorghum": "Sorghum", "bambara_nut": "Bambara groundnut", "african_yam_bean": "African yam bean",
      "kerstrings_groundnut": "Kersting's groundnut", "cowpea": "Cowpea†", "marama_beans": "Marama bean", "taro": "Taro†",
      "tiger_nut": "Tiger nut", "african_yam": "African yam†"}
fig = plt.figure(figsize=(183 * MM, 150 * MM))
a = fig.add_axes([0.08, 0.66, 0.9, 0.29])
xs = np.arange(len(order))
wd = 0.2
cols = [BAR["SSP1-2.6"], BAR["SSP2-4.5"], BAR["SSP5-8.5"], COL["U"]]
for k, s in enumerate(["SSP1-2.6", "SSP2-4.5", "SSP5-8.5", "robust"]):
    v = [sw[c]["main"][s]["SC"] for c in order]
    a.bar(xs + (k - 1.5) * wd, v, wd * 0.9, color=cols[k], label="All three SSPs (robust)" if s == "robust" else s, zorder=3)
a.set_xticks(xs)
a.set_xticklabels([NM[c] for c in order], fontsize=6.5, color=INK)
a.set_ylabel("Swap coverage (% of loss area)")
a.set_ylim(0, 100)
a.legend(ncol=4, fontsize=6.3, loc="upper left", bbox_to_anchor=(0, 1.13))
clean(a, grid="y")
panel(a, "a", x=-0.05, y=1.04)
b = fig.add_axes([0.17, 0.12, 0.72, 0.43])
M = np.array([[sw[c]["main"]["robust"]["CC"].get(u, np.nan) for u in cands] for c in order], float)
im = b.imshow(np.ma.masked_invalid(M), cmap=ListedColormap(plt.get_cmap("Blues")(np.linspace(0.08, 0.95, 256))), vmin=0, vmax=100, aspect="auto")
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        if not np.isnan(M[i, j]):
            b.text(j, i, f"{M[i, j]:.0f}", ha="center", va="center", fontsize=6.3, color="white" if M[i, j] > 55 else INK)
b.set_xticks(range(len(cands)))
b.set_xticklabels([CN[c] for c in cands], rotation=35, ha="right", fontsize=6.3, color=INK)
b.set_yticks(range(len(order)))
b.set_yticklabels([NM[c] for c in order], fontsize=6.5, color=INK)
for xv in (2.5, 7.5):
    b.axvline(xv, color="white", lw=2)
for yv in (3.5, 5.5):
    b.axhline(yv, color="white", lw=2)
for s in b.spines.values():
    s.set_visible(False)
b.tick_params(length=0)
cax = fig.add_axes([0.905, 0.12, 0.012, 0.43])
cb = fig.colorbar(im, cax=cax)
cb.set_label("Candidate contribution (% of robust loss area)", fontsize=6.3)
cb.outline.set_visible(False)
panel(b, "b", x=-0.12, y=1.02)
fig.savefig(OUT + "fig5_swap_coverage.png")
plt.close(fig)
print("figs ok")
