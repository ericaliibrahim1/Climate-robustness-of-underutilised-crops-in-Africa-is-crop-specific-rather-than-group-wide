"""Class areas (Africa and global) and Africa class-transition matrices for every crop raster."""
import pickle
import sys
import time

import numpy as np
import rasterio
from rasterio.windows import Window

sys.path.insert(0, ".")
from common import ALL, FUT, GH, GTR, GW, H, ROWAREA, W, africa_mask, fname, raster_crops, read_africa, row_areas

OUT = "./areas.pkl"
crops = raster_crops()
mask = africa_mask()
np.save("./afmask.npy", mask)

res = {"africa": {}, "global": {}, "trans": {}}
t0 = time.time()
STRIP = 1000
for c in crops:
    afr = {s: np.zeros(4) for s in ALL}
    T = {s: np.zeros((4, 4)) for s in FUT}
    for r0 in range(0, H, STRIP):
        n = min(STRIP, H - r0)
        m = mask[r0:r0 + n]
        A = np.broadcast_to(ROWAREA[r0:r0 + n, None], (n, W))
        cur = read_africa(c, "current", r0, n)
        ok = m & (cur != 255)
        afr["current"] += np.bincount(cur[ok], weights=A[ok], minlength=4)[:4]
        for s in FUT:
            f = read_africa(c, s, r0, n)
            k = m & (f != 255)
            afr[s] += np.bincount(f[k], weights=A[k], minlength=4)[:4]
            kk = ok & (f != 255)
            T[s] += np.bincount(cur[kk].astype(np.int64) * 4 + f[kk], weights=A[kk], minlength=16).reshape(4, 4)
    res["africa"][c] = afr
    res["trans"][c] = T
    # global areas
    glob_ = {}
    for s in ALL:
        acc = np.zeros(4)
        with rasterio.open(fname(c, s)) as r:
            for r0 in range(0, GH, 1200):
                n = min(1200, GH - r0)
                a = r.read(1, window=Window(0, r0, GW, n))
                A = np.broadcast_to(row_areas(GTR, n, r0)[:, None], (n, GW))
                k = a != 255
                acc += np.bincount(a[k], weights=A[k], minlength=4)[:4]
        glob_[s] = acc
    res["global"][c] = glob_
    print(c, round(time.time() - t0), flush=True)
pickle.dump(res, open(OUT, "wb"))
print("done")
