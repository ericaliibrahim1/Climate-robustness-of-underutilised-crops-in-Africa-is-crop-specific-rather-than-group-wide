"""Comparative statistics for the 37-crop panel (Methods 2.8-2.9) and summaries of rasters and swap results."""
import json
import pickle
import sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, ".")
SI2 = "./Supplementary_Data_1_suitability_areas.xlsx"
AREAS = pickle.load(open("./areas.pkl", "rb"))
SW = pickle.load(open("./swap.pkl", "rb"))
FUT = ["SSP1-2.6", "SSP2-4.5", "SSP5-8.5"]

# key: (label, group, category, tier, raster file key, SI2 name)
META = {
    "fonio": ("White fonio", "U", "Cereal", 0, "fonio", "Fonio"),
    "teff": ("Teff", "U", "Cereal", 0, "teff", "Teff"),
    "wild_rice": ("African wild rice", "U", "Cereal", 2, "african_wild_rice", "African Wild Rice"),
    "sorghum": ("Sorghum", "U", "Cereal", 3, "sorghum", "Sorghum"),
    "mango": ("African mango", "U", "Fruit and tree", 2, "african_mango", "African Mango"),
    "velvet": ("Velvet tamarind", "U", "Fruit and tree", 1, "velvet_tamarind", "Velvet Tamarind"),
    "baobab": ("African baobab", "U", "Fruit and tree", 2, "baobab", "Baobab"),
    "jackfruit": ("Jackfruit", "U", "Fruit and tree", 1, "jackfruit", "Jackfruit"),
    "kola": ("Bitter kola", "U", "Fruit and tree", 2, "bitter_kola", "Bitter Kola"),
    "bitterleaf": ("Bitter leaf", "U", "Leafy vegetable", 0, "bitter_leaf", "Bitter Leaf"),
    "jute": ("Jute mallow", "U", "Leafy vegetable", 1, "jute_mallow", "Jute Mallow"),
    "amaranth": ("Spiny amaranth", "U", "Leafy vegetable", 1, "amaranth", "Amaranth"),
    "moringa": ("Moringa", "U", "Leafy vegetable", 1, "moringa", "Moringa"),
    "spider": ("Spider plant", "U", "Leafy vegetable", 1, "spider_plant", "Spider Plant"),
    "bambara": ("Bambara groundnut", "U", "Legume", 2, "bambara_nut", "Bambara Nut"),
    "ayb": ("African yam bean", "U", "Legume", 2, "african_yam_bean", "African Yam Beans"),
    "kersting": ("Kersting's groundnut", "U", "Legume", 2, "kerstrings_groundnut", "Kerstings Groundnut"),
    "cowpea": ("Cowpea", "U", "Legume", 3, "cowpea", "Cowpea"),
    "marama": ("Marama bean", "U", "Legume", 0, "marama_beans", "Marama"),
    "egusi": ("Egusi melon", "U", "Oilseed", 0, "melon", "Melon"),
    "sesame": ("Sesame", "U", "Oilseed", 0, "sesamum", "Sesamum"),
    "taro": ("Taro", "U", "Root and tuber", 1, "taro", "Taro"),
    "tigernut": ("Tiger nut", "U", "Root and tuber", 0, "tiger_nut", "Tiger Nut"),
    "yam": ("African yam", "U", "Root and tuber", 3, "african_yam", "African Yam"),
    "rice": ("Asian rice", "C", "Cereal", 3, "rice", "Rice"),
    "wheat": ("Wheat", "C", "Cereal", 3, "wheat", "Wheat"),
    "maize": ("Maize", "C", "Cereal", 3, "maize", "Maize"),
    "millet": ("Pearl millet", "C", "Cereal", 3, "pearl_millet", "Pearl Millet"),
    "chickpea": ("Chickpea", "C", "Legume", 3, "chickpea", "Chickpea"),
    "bean": ("Common bean", "C", "Legume", 3, "common_bean", "Common Bean"),
    "groundnut": ("Groundnut", "C", "Legume", 3, "groundnut", "Groundnut"),
    "cassava": ("Cassava", "C", "Root and tuber", 3, "cassava", "Cassava"),
    "sweetpotato": ("Sweetpotato", "C", "Root and tuber", 3, "sweet_potato", "Sweet Potato"),
    "banana": ("Banana and plantain", "C", "Root and tuber", 3, "banana_plantain", "Banana Plantain"),
    "faidherbia": ("Faidherbia", "C", "Agroforestry", 2, "faidherbia_albida", "Faidherbia Albida"),
    "gliricidia": ("Gliricidia", "C", "Agroforestry", 2, "gliricidia_sepium", "Gliricidia Sepium"),
    "calliandra": ("Calliandra", "C", "Agroforestry", 2, "calliandra_calothyrsus", "Calliandra Calothyrsus"),
}

# ---------------- Africa areas: SI 2, with calliandra from its raster (SI 2 row duplicated taro)
raw = pd.read_excel(SI2, header=1).iloc[:, :23]
raw.columns = ["Rank", "Crop", "L0", "M0", "H0", "MH0", "L1", "M1", "H1", "MH1", "D1r", "L2", "M2", "H2", "MH2", "D2r",
               "L5", "M5", "H5", "MH5", "D5r", "Dbar_r", "R_r"]
si = raw.set_index("Crop")
rows = []
for k, (lab, g, cat, tier, rk, sn) in META.items():
    if k == "calliandra":
        a = AREAS["africa"][rk]
        vals = {}
        for s, i in zip(["current"] + FUT, "0125"):
            vals[f"L{i}"], vals[f"M{i}"], vals[f"H{i}"] = a[s][1], a[s][2], a[s][3]
        src = "raster"
    else:
        r = si.loc[sn]
        vals = {f"{x}{i}": r[f"{x}{i}"] for x in "LMH" for i in "0125"}
        src = "SI 2"
    rows.append(dict(key=k, label=lab, group=g, category=cat, tier=tier, rkey=rk, source=src, **vals))
df = pd.DataFrame(rows)
for i in "0125":
    df[f"MH{i}"] = df[f"M{i}"] + df[f"H{i}"]
for i in "125":
    df[f"D{i}"] = (df[f"MH{i}"] - df.MH0) / df.MH0 * 100
    df[f"DH{i}"] = (df[f"H{i}"] - df.H0) / df.H0 * 100
df["Dbar"] = df[["D1", "D2", "D5"]].mean(axis=1)
df["R"] = df[["D1", "D2", "D5"]].max(axis=1) - df[["D1", "D2", "D5"]].min(axis=1)
df["DHbar"] = df[["DH1", "DH2", "DH5"]].mean(axis=1)
df = df.sort_values("Dbar", ascending=False).reset_index(drop=True)
df["rank"] = np.arange(1, len(df) + 1)

# ---------------- raster verification against the Africa areas used
qc = []
for _, r in df.iterrows():
    a = AREAS["africa"][r.rkey]
    rmh0 = a["current"][2] + a["current"][3]
    rD = np.mean([((a[s][2] + a[s][3]) - rmh0) / rmh0 * 100 if rmh0 > 0 else np.nan for s in FUT])
    qc.append(dict(key=r.key, raster_MH0=rmh0, diff_pct=100 * (rmh0 - r.MH0) / r.MH0, raster_Dbar=rD, dDbar=rD - r.Dbar))
qc = pd.DataFrame(qc)
qc["verified"] = (qc.diff_pct.abs() < 1) & (qc.dDbar.abs() < 0.5)
df = df.merge(qc, on="key")


# ---------------- group comparison
def cliff(x, y):
    return float(np.sign(np.asarray(x, float)[:, None] - np.asarray(y, float)[None, :]).mean())


def mag(d):
    a = abs(d)
    return "Negligible" if a < 0.147 else "Small" if a < 0.33 else "Medium" if a < 0.474 else "Large"


def perm(x, y, n=20000, seed=1):
    rng = np.random.default_rng(seed)
    pooled = np.concatenate([x, y]).astype(float)
    k = len(x)
    obs = abs(np.median(x) - np.median(y))
    c = 0
    for _ in range(n):
        rng.shuffle(pooled)
        c += abs(np.median(pooled[:k]) - np.median(pooled[k:])) >= obs
    return (c + 1) / (n + 1)


def compare(d, var):
    u = d.loc[d.group == "U", var].values
    c = d.loc[d.group == "C", var].values
    dl = cliff(u, c)
    return dict(nU=len(u), nC=len(c), medU=float(np.median(u)), medC=float(np.median(c)),
                meanU=float(u.mean()), meanC=float(c.mean()), delta=dl, mag=mag(dl),
                p_mw=float(stats.mannwhitneyu(u, c, alternative="two-sided").pvalue), p_perm=float(perm(u, c)))


VARS = {"Dbar": "Δ̄", "R": "RΔ", "D5": "Δ SSP5-8.5", "DHbar": "Δ̄H"}
t_group = {v: compare(df, v) for v in VARS}
DUP = set()  # leucaena removed; calliandra corrected -> no duplicated records remain
subsets = {
    "All crops": df,
    "Excluding agroforestry trees": df[df.category != "Agroforestry"],
    "Excluding sorghum and cowpea": df[~df.key.isin(["sorghum", "cowpea"])],
    "Food crops only": df[(df.category != "Agroforestry") & ~df.key.isin(["sorghum", "cowpea", "taro", "marama"])],
    "Verified rasters only": df[df.verified],
}
t_sens = {k: {"Dbar": compare(s, "Dbar"), "R": compare(s, "R")} for k, s in subsets.items()}

# ---------------- ranking composition
N, K = len(df), int((df.group == "U").sum())
rank = {}
for name, order in [("top_Dbar", df.sort_values("Dbar", ascending=False)), ("bottom_Dbar", df.sort_values("Dbar")),
                    ("top_DHbar", df.sort_values("DHbar", ascending=False))]:
    top = order.head(10)
    k = int((top.group == "U").sum())
    rank[name] = dict(k=k, expected=10 * K / N, p=float(stats.hypergeom.sf(k - 1, N, K, 10)), crops=list(top.label),
                      commons=list(top.loc[top.group == "C", "label"]))

# ---------------- investment
rho, prho = stats.spearmanr(df.tier, df.Dbar)
med = float(df.Dbar.median())
df["quadrant"] = np.where(df.tier <= 1, np.where(df.Dbar >= med, "Neglected opportunities", "Low climate priority"),
                          np.where(df.Dbar >= med, "Well placed", "Investment at risk"))
tier_summary = df.groupby("tier").Dbar.agg(["count", "median", "mean"]).reset_index().to_dict("records")

# ---------------- transitions (rasters) for swap-analysis crops and all verified crops
trans = {}
for rk, T in AREAS["trans"].items():
    out = {}
    for s in FUT:
        M = T[s]
        fav0 = M[2:, :].sum()
        out[s] = dict(fav0=fav0, lost=M[2:, :2].sum(), gained=M[:2, 2:].sum(), down=M[3, 2], up=M[2, 3])
    f = np.mean([out[s]["fav0"] for s in FUT])
    trans[rk] = {m: (100 * np.mean([out[s][m] for s in FUT]) / f if f > 0 else np.nan) for m in ["lost", "gained", "down", "up"]}
    trans[rk]["fav0"] = f

# ---------------- global areas (verified rasters only)
glob = {}
for _, r in df.iterrows():
    gA = AREAS["global"][r.rkey]
    aA = AREAS["africa"][r.rkey]
    gmh = {s: gA[s][2] + gA[s][3] for s in gA}
    amh = {s: aA[s][2] + aA[s][3] for s in aA}
    if gmh["current"] <= 0:
        continue
    glob[r.key] = dict(label=r.label, group=r.group, verified=bool(r.verified),
                       G0=gmh["current"], Gbar=float(np.mean([(gmh[s] - gmh["current"]) / gmh["current"] * 100 for s in FUT])),
                       africa_share=amh["current"] / gmh["current"] * 100,
                       outside0=gmh["current"] - amh["current"],
                       outside_bar=float(np.mean([((gmh[s] - amh[s]) - (gmh["current"] - amh["current"])) /
                                                  (gmh["current"] - amh["current"]) * 100 for s in FUT]))
                       if gmh["current"] - amh["current"] > 0 else np.nan)

# ---------------- swap summaries
swap = {}
for (com, sett, scen), d in SW["res"].items():
    if scen == "current":
        continue
    L = d["loss"]
    fav0 = SW["res"][(com, sett, "current")]["fav0"]
    swap.setdefault(com, {}).setdefault(sett, {})[scen] = dict(
        fav0=fav0, loss=L, loss_pct=100 * L / fav0, SC=100 * d["covered"] / L if L else np.nan,
        D=d["depthsum"] / L if L else np.nan,
        CC={k[3:]: 100 * v / L for k, v in d.items() if k.startswith("cc_")})

out = dict(df=df.to_dict("records"), group=t_group, sens=t_sens, rank=rank, rho=float(rho), prho=float(prho), median=med,
           tiers=tier_summary, trans=trans, glob=glob, swap=swap, N=N, K=K)
pickle.dump(out, open("./stats.pkl", "wb"))
df.to_csv("./crop_metrics_37.csv", index=False)

pd.set_option("display.width", 250)
print(df[["rank", "label", "group", "tier", "MH0", "D1", "D2", "D5", "Dbar", "R", "DHbar", "source", "diff_pct", "dDbar", "verified"]].round(2).to_string(index=False))
print(json.dumps({k: {kk: (round(vv, 3) if isinstance(vv, float) else vv) for kk, vv in v.items()} for k, v in t_group.items()}, indent=0, ensure_ascii=False))
for k, v in t_sens.items():
    print(k, v["Dbar"]["nU"], v["Dbar"]["nC"], round(v["Dbar"]["delta"], 2), round(v["Dbar"]["p_mw"], 3), round(v["R"]["delta"], 2), round(v["R"]["p_mw"], 3))
print(json.dumps(rank, indent=0))
print("rho", round(rho, 3), round(prho, 3), "median", round(med, 2))
print(df.groupby("quadrant").label.apply(list).to_dict())
