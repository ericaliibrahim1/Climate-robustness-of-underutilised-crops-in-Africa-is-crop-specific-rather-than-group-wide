"""Shared settings for the suitability raster analyses (Africa clip, cell areas, file names)."""
import glob
import json
import re

import numpy as np
import rasterio
from rasterio.features import geometry_mask
from rasterio.windows import Window, from_bounds
from shapely.geometry import shape
from shapely.ops import unary_union

RD = "./rasters/"
NE = "./ne50.geojson"
SCEN = {"current": "current", "SSP1-2.6": "best", "SSP2-4.5": "moderate", "SSP5-8.5": "worst"}
FUT = ["SSP1-2.6", "SSP2-4.5", "SSP5-8.5"]
ALL = ["current"] + FUT
R_EARTH = 6371.0088  # km


def fname(crop, scen):
    mid = "fuzzy_continuous" if crop == "african_yam_bean" else "continuous"
    return f"{RD}{SCEN[scen]}_{mid}_{crop}_classified.tif"


def raster_crops():
    pat = r"^(current|best|moderate|worst)_(fuzzy_)?continuous_|_classified\.tif$"
    return sorted({re.sub(pat, "", f.split("/")[-1]) for f in glob.glob(RD + "*.tif")})


def row_areas(transform, nrows, row0=0):
    """Area (km2) of one cell in each row, on a sphere."""
    d = np.deg2rad(abs(transform.a))
    top = transform.f + (row0 + np.arange(nrows)) * transform.e
    return R_EARTH ** 2 * d * np.abs(np.sin(np.deg2rad(top)) - np.sin(np.deg2rad(top + transform.e)))


_g = json.load(open(NE))
AFRICA = unary_union([shape(f["geometry"]) for f in _g["features"] if f["properties"].get("CONTINENT") == "Africa"])

with rasterio.open(fname("maize", "current")) as _r:
    GTR = _r.transform
    GH, GW = _r.height, _r.width
    WIN = from_bounds(*AFRICA.bounds, GTR).round_offsets().round_lengths()
    WTR = _r.window_transform(WIN)
H, W = int(WIN.height), int(WIN.width)
ROWAREA = row_areas(WTR, H)


def africa_mask():
    return ~geometry_mask([AFRICA.__geo_interface__], out_shape=(H, W), transform=WTR)


def read_africa(crop, scen, row0=0, nrows=None):
    nrows = H if nrows is None else nrows
    with rasterio.open(fname(crop, scen)) as r:
        return r.read(1, window=Window(WIN.col_off, WIN.row_off + row0, W, nrows))
